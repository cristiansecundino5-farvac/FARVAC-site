# FARVAC sitio — Repo listo para Netlify + Decap CMS

Este paquete ya incluye:

- `/admin` con Decap CMS (Netlify CMS) para **Álbumes** y **Blog**.
- `/albums/albums.json` y `/posts/posts.json`.
- Páginas: `index.html`, `fotos.html`, `blog.html`.

## Pasos para montar en GitHub + Netlify

1) Crea un repositorio en GitHub (p.ej. `farvac-site`) y **sube todo el contenido** de este ZIP a la raíz del repo.

2) En Netlify:
   - **Sites → Add new site → Import from Git** y elige tu repo.
   - Build command: *(vacío)*, Publish directory: `"."`

3) Activa **Identity**: `Site settings → Identity → Enable Identity`.

4) Activa **Git Gateway**: `Identity → Settings → Services → Enable Git Gateway`.

5) **Invita** tu correo en Identity: `Identity → Invite users`.

6) Entra al panel: `https://TU-DOMINIO/admin` (ej. `https://farvac.org/admin`),
   inicia sesión y edita colecciones **Álbumes** y **Blog**.

## Álbumes

- Las imágenes se subirán a `/assets/uploads/`.
- `fotos.html` lee `/albums/albums.json` y muestra los álbumes.


## Blog

- Los posts están en `/posts/posts.json` (colección **Blog**).
- La lista/detalle está en `/blog.html` con la url `?p=slug`.

¡Listo!
