# FARVAC sitio estático (Netlify + GitHub)

Este repo contiene el sitio estático de FARVAC listo para que Netlify publique directamente desde GitHub.

## Estructura
- `index.html`
- `styles.css`
- `script.js`
- `img/` (logos, hero, etc.)
- `fotos/evento-01/cover.jpg`
- `netlify.toml` (indica que no hay build y que se publique desde la raíz)

## Subir a GitHub (vía Web)
1. Crea (o abre) el repositorio de FARVAC en GitHub.
2. Click **Add file → Upload files**.
3. Arrastra **TODO el contenido** de esta carpeta (incluidas `img/` y `fotos/`).
4. Haz **Commit changes**.
5. En Netlify, en tu sitio conectado, ve a **Deploys** y espera el **Auto deploy**.

## Tip
- Las rutas de imágenes usan `/img/...`. Asegúrate de que el deploy apunte a la raíz del dominio (ej. farvac.org).

